# Sistem Pendukung Keputusan Pemilihan HP

[![](https://gitlab.com/gitlab-org/gitlab-ee/badges/master/build.svg)](https://wahidari.github.io)
[![](https://semaphoreci.com/api/v1/projects/2f1a5809-418b-4cc2-a1f4-819607579fe7/400484/shields_badge.svg)](https://wahidari.github.io)
[![](https://img.shields.io/badge/docs-latest-brightgreen.svg?style=flat&maxAge=86400)](https://wahidari.github.io)
[![](https://img.shields.io/badge/Find%20Me-%40wahidari-009688.svg?style=social)](https://wahidari.github.io)

## Language

- [![](https://img.shields.io/badge/html-5-FF5722.svg)](https://www.w3schools.com/html/default.asp) 
- [![](https://img.shields.io/badge/css-3-03A9F4.svg)](https://www.w3schools.com/cssref/)
- [![](https://img.shields.io/badge/javascript-1.8-FFCA28.svg)](https://www.w3schools.com/js/default.asp)
- [![](https://img.shields.io/badge/php-7.1.8-673AB7.svg)](https://www.php.net/) 
- [![](https://img.shields.io/badge/mysql-5.0.12-yellow.svg)](https://www.mysql.com/) 

## Screenshot

- ### Web
    
    ![](https://raw.githubusercontent.com/wahidari/spk_pemilihan_hp/master/ss/a.PNG)
    
    ![](https://raw.githubusercontent.com/wahidari/spk_pemilihan_hp/master/ss/b.PNG)
    
    ![](https://raw.githubusercontent.com/wahidari/spk_pemilihan_hp/master/ss/c.PNG)
    
    ![](https://raw.githubusercontent.com/wahidari/spk_pemilihan_hp/master/ss/d.PNG)
    
    ![](https://raw.githubusercontent.com/wahidari/spk_pemilihan_hp/master/ss/e.PNG)
    
    ![](https://raw.githubusercontent.com/wahidari/spk_pemilihan_hp/master/ss/f.PNG)
    
    ![](https://raw.githubusercontent.com/wahidari/spk_pemilihan_hp/master/ss/g.PNG)
    
## License
> This program is Free Software: 
You can use, study, share and improve it at your will. Specifically you can redistribute and/or modify it under the terms of the [GNU General Public License](https://www.gnu.org/licenses/gpl.html) 
as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
